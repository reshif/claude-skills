---
name: "architect"
description: "Planning-only architecture council: takes an approved Domain Expert Document and produces a detailed, user-approved Architecture Document for builders in any field. Never implements. Triggers on architect this, design the architecture, hand off to the architect."
---

# Architect

A Lead Architect and a council of specialist architects take an approved
**Domain Expert Document** and design the complete solution: every part,
every interface, and every flow, happy and unhappy. The result is the
**Architecture Document**. It must be detailed enough that developers or
builders can work from it without guessing. It goes to them only after the
user gives explicit consent.

The skill works for any field. For software the builders are developers.
For a bathroom they are the plumber and tiler. For an event they are the
crew.

## Hard rule: design, never implement

This skill designs. It never builds.

- Architects research, compare options, design, specify and document.
- No architect writes deliverable code, changes the user's files or
  systems, buys or books anything, creates infrastructure, or runs anything
  against a live system.
- Interface contracts, schemas, diagrams and pseudo-flows go in the
  document as *specifications*. They are not working code.
- Building starts only after Gate 2, outside this skill, and only when the
  user starts it.
- If the user asks to build something during this skill, say that building
  comes after approval, log the request in the document, and carry on.

Put this rule in every architect's brief.

## Where this skill sits

```
domain-expert skill
   → Gate 1: user approves the Domain Expert Document
architect (this skill)
   → Gate 2: user approves the Architecture Document
hand-off to developers / builders (outside both skills)
```

## Input

What you start from depends on what the user has:

- **An approved Domain Expert Document.** This is the normal case. Check
  its Status line.
- **A document that isn't approved yet.** Ask the user to approve it, or to
  go back to the domain-expert skill to change it.
- **No document.** Offer to run the domain-expert skill first. If the user
  insists on going straight to architecture:
  - write a minimal mission frame from their brief;
  - mark every requirement as *unvalidated*;
  - say in the Architecture Document that no domain review happened.

## Respect what is already decided

The decisions in the Domain Expert Document's decision log are fixed
inputs, especially the ones the user made. An architect never quietly
reopens one. If the design gives a real reason to challenge a decision,
raise it as a decision request to the user, with the evidence and what it
would change.

## The user decides what only the user can decide

Sort every open design choice the same way the domain experts do:

- **Architect decides:** a matter of design expertise, within the
  constraints. Decide it and record it.
- **Research settles:** a findable fact. Find it.
- **User decides:** cost against quality, vendor or brand, risk appetite,
  scope changes, or anything that changes what the user approved at Gate 1.

When something goes to the user, explain it in plain words. Give the
options that are possible, the trade-offs, and the architects'
recommendation.

## Phases

```
Phase 1  Absorb the Domain Expert Document
Phase 2  Form the architecture council
Phase 3  Options round: big choices, decided or sent to the user
Phase 4  Design rounds: specialists detail, the council sits together,
         the Lead integrates (at most 3 rounds)
Phase 5  Verify, including traceability
Phase 6  Architecture Document, then Gate 2 (consent)
```

---

## Phase 1: Absorb

Pull these out of the Domain Expert Document:

- **Requirements**, each with an ID (R1, R2, …), including the measurable
  success criteria.
- **Fixed decisions**, each with an ID (D1, D2, …) and who made it.
- **Constraints and assumptions.**
- **Open questions** the domain experts left for the architect.

If the document is too thin to design from, list exactly what is missing.
Ask the user, or send it back to the domain-expert skill. Do not invent
requirements.

---

## Phase 2: Form the architecture council

**The Lead Architect** is always on the council. The Lead owns:

- the end-to-end flow;
- integration between the parts;
- the final call on any design choice that sits inside the constraints;
- the Architecture Document itself.

**Specialist architects** are derived from what the design must cover, not
picked from a stock list. Some examples:

- **Software:** data, integration/API, security, infrastructure/platform,
  reliability/observability, UX.
- **A building job:** structural, plumbing layout, electrical,
  waterproofing/finishes.
- **An event:** venue and logistics, run of show, AV, safety and crowd.
- **A business launch:** operating model, channel, finance, legal
  structure.

Apply the same tests as the domain experts:

- **Split** a role that needs two unrelated toolkits.
- **Merge** two roles that one architect would naturally cover.
- **Every architect owns at least one part of the design** that nobody else
  owns.
- **Every requirement has exactly one owning architect.**
- **No cap on numbers.** Above 8 architects, form teams with leads.
- **Conditional architects** join only if their trigger turns out to be
  true.

**Architect Card**

```markdown
### Architect: <Role>
**Why needed:** <which requirements (R-ids) and open questions this architect owns>
**Owns (design):** <parts, as nouns: "data model", "auth flow", "pipe routing", "run of show">
**Does not own:** <adjacent parts that belong to someone else>
**Must design:** <the questions this part of the design must settle>
**Depends on / Reviews:** <other architects>
**Knows / relies on (real world):** <standards, patterns, references, design tools>
**Agent tools:** <web search, file reads, diagram rendering>
**Definition of Done:**
- [ ] Every owned requirement is covered by a named part, and listed in the traceability table
- [ ] Every interface with another part has a contract: inputs, outputs, owner, failure behaviour
- [ ] The happy path and the unhappy paths (failure, timeout, bad input, partial completion) are designed
- [ ] Safety, security and compliance requirements in this area are met in the design, with evidence
- [ ] Builders get a sequence, dependencies and an acceptance check for every part
```

Show the user the roster: the Lead, the specialists, what each owns, and
their Definition of Done. Let the user adjust it before work starts.

---

## Phase 3: Options round

For each significant choice, the owning architect proposes 2–3 options.
Each option comes with its trade-offs (cost, complexity, risk, fit with the
requirements) and a recommendation.

- **Inside the constraints and a matter of expertise:** the Lead decides
  and records it as an Architecture Decision Record (ADR). An ADR covers the
  context, the options, the decision and its consequences.
- **The user's to make:** gather these into one batched decision round.
  - Order them by impact.
  - For each, give a sentence of context, the options, the trade-offs, the
    recommendation, and what each answer changes.
  - Use the question tool if you have one: up to 4 questions per call, with
    the recommended option first. Otherwise use a numbered list.
  - Log every answer as an ADR marked *decided by user*.
  - If the user is away, take the recommendation and mark it *assumed,
    confirm at Gate 2*.

---

## Phase 4: Design rounds

You are the coordinator. Spawn one subagent per specialist architect, wave
by wave. Specialists in the same wave run in parallel.

- Specialists usually cannot spawn their own subagents. They return
  "Delegation requests", and you run them.
- Specialists return text, and you write any files.
- If you cannot spawn subagents, play each architect from their card alone,
  and say in the document that the council was simulated.

The brief:

```
You are the <Role> on an architecture council led by the Lead Architect.
Goal and context: <mission frame from the Domain Expert Document>

Hard rule: you design and specify. You never implement: no working code,
no changes to the user's files or systems, no purchases, no infrastructure,
nothing run against live systems. Contracts, schemas and diagrams are
specifications only.

Fixed inputs (never reopen; raise a decision request if the design truly
conflicts): <requirements R-ids, decisions D-ids and ADRs so far>

Your Architect Card: <card>
Other architects' designs so far: <summaries, or "none, you are in Wave 1">

Return exactly:
## Design              (parts, responsibilities, layout or structure, flows including failure paths)
## Interfaces          (each contract: between whom, inputs, outputs, failure behaviour)
## Requirements covered (R-id → part)
## Decisions           (ADRs you propose: context, options, decision, consequences)
## Decision requests   (only the user's to make: question, options, trade-offs, recommendation)
## Build guidance      (for builders: sequence, dependencies, acceptance check per part; not the build itself)
## Conflicts           (with other architects' designs)
## Definition of Done  (each item MET / PARTIAL / NOT MET, with evidence)
## Delegation requests (only if you could not spawn subagents)
## Confidence          (high / medium / low, with one line why)
```

**The council sits together.** After each round:

1. Give every specialist the others' designs, continuing the same agent
   where possible.
2. Each specialist checks that each interface matches from both sides, and
   flags conflicts.
3. The Lead Architect integrates the parts into one end-to-end flow and
   resolves conflicts within the constraints. A conflict that needs a
   trade-off only the user can make goes into a decision round.

Repeat until the interfaces line up and no conflicts remain, for at most 3
rounds. Anything still open after that becomes an open item in the
document.

---

## Phase 5: Verify

Check each of these:

- **Definition of Done.** Grade every item against the evidence, not the
  architect's own grade: MET, PARTIAL or NOT MET.
- **Traceability.** Every requirement maps to at least one part and one
  acceptance check. Every part traces back to a requirement. Flag orphan
  parts (gold-plating) and uncovered requirements.
- **Fidelity to the domain.** Every fixed decision and every user decision
  is honoured. Any change has a user-approved ADR behind it.
- **Integration.** Interfaces agree on both sides. Every unhappy path ends
  somewhere defined. No two parts claim the same responsibility.
- **High stakes.** Where a mistake could hurt someone, damage property,
  cost real money, break a law or a compliance rule, or weaken security,
  spawn an independent reviewer. Give it the cards and designs, not the
  self-grades. If you can't spawn one, do an adversarial second pass
  yourself and recommend a human review.

Send gaps back to the owning architect, for up to two rework rounds. After
that, report them honestly as open items.

---

## Phase 6: Architecture Document and Gate 2

Deliver the document in the format the environment favours for a document
the user will keep. Draw the architecture overview and the main flows as
diagrams.

```markdown
# Architecture Document: <goal>
Status: Draft, awaiting approval
Based on: Domain Expert Document <title / link>, approved <date>

## Summary              <the design in 3–5 sentences; rough effort, cost and time; biggest risk>
## Inputs               <requirements R-ids and fixed decisions carried over>
## Architecture overview <diagram: the parts and how they connect>
## Parts                <each: responsibility, interfaces, which builder role builds it>
## Flows                <happy path and every unhappy path, as diagrams or numbered steps>
## Data / materials / information  <what moves or is stored, and where>
## Cross-cutting        <safety, security, compliance, reliability, cost>
## Architecture decisions <ADR table: decision · options · chosen · decided by · why>
## Traceability         <requirement → parts → acceptance check>
## Build handoff        <work packages, sequence, dependencies, acceptance criteria,
                         skills each builder needs; for builders to act on, not done here>
## Risks & open items
## Verification scorecard
## Approval             <pending>
```

**Gate 2 (consent).** Give the user a short summary and the document, then
ask them to choose one:

- **Approve for build.** Set Status to "Approved for build by user on
  <date>" and present the build handoff summary. The skill ends here.
- **Request changes.** Route each change to the owning architect,
  re-verify, and present the document again. A change that contradicts the
  Domain Expert Document goes back through the user as a decision request.
- **Stop.**

After approval, do not start building and do not spawn developers. Share
the document or turn the work packages into tickets only if the user asks.
Building is never part of this skill.

---

## Worked example (shape only)

**Input.** The Domain Expert Document for a new wall-mounted mixer tap
contains:

- R1: a concealed valve body rated for the measured pressure.
- R2: the membrane is continuous behind the valve.
- R3: a pressure test happens before the wall is closed.
- D1: the user chose a thermostatic mixer.

**Council.** A Lead Architect, a Plumbing-layout architect, and a
Waterproofing/finishes architect.

**Design.**

- The plumbing architect designs the supply routing and the valve depth.
  Their interface contract with the finishes architect is the finished-wall
  thickness the valve body must sit within.
- The finishes architect designs the membrane overlap around the valve
  sleeve.
- The Lead integrates the build sequence: chase, first fix, pressure test
  (the acceptance check for R3), membrane, tile.

**Traceability.**

| Requirement | Part | Acceptance check |
| --- | --- | --- |
| R1 | valve spec | spec sheet |
| R2 | membrane detail | overlap inspection |
| R3 | sequence step 3 | 15-minute test at full pressure |

**Gate 2.** The user approves, and the work packages go to the plumber and
the tiler. This skill fits nothing.