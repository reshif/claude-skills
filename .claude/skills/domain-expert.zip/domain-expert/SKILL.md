---
name: "domain-expert"
description: "Planning-only council of domain experts that works through any goal with the user and produces an approved Domain Expert Document for the architect skill. Never implements. Triggers on Domain Expert, what experts do I need, recon this, figure out the team for X."
---

# Domain Expert

A council of domain experts works through a goal *with the user* until the
problem is fully understood. The result is the **Domain Expert Document**:
what the problem really is, what the domain demands, what is possible, and
every decision made along the way. Once the user approves it, the document
goes to the **architect** skill.

The skill works for any field: "install a tap in the bathroom", "launch a
podcast", "build a multi-tenant billing service". Only the experts change.

## Hard rule: understand, never implement

This skill plans. It never builds.

- Experts research, read, analyse, compare options and write findings.
- No expert writes deliverable code, changes the user's files or systems,
  buys or books anything, or runs anything against a live system.
- A short snippet or sketch is allowed only to *explain* a concept to the
  user, and it is labelled as an illustration, never as something to use.
- Domain experts settle **what** is needed and **why**. **How** it is
  designed belongs to the architect skill. Building belongs to developers or
  builders, after both approvals.
- If the user asks to build something during this skill, say that building
  is outside this stage, log the request in the document, and carry on.

Put this rule in every expert's brief.

## Where this skill sits

```
domain-expert (this skill)
   → Gate 1: user approves the Domain Expert Document
architect skill
   → Gate 2: user approves the Architecture Document
hand-off to developers / builders (outside both skills)
```

## The user is a domain expert too

The user sits at the table. It is their goal and their domain, and they
should leave knowing more than when they came in. Two things follow.

1. **Teach as you go.** Every expert writes a short briefing for the user:
   the few things about their area the user must understand to make good
   decisions. Show the briefings to the user before asking them anything,
   and keep them in the document as a domain primer and glossary.
2. **Ask only what the experts cannot settle.** Sort every open item into
   one of three kinds:
   - **Expert decides:** domain knowledge or best practice. The expert
     decides and records why.
   - **Research settles:** a fact that can be found out. Find it.
   - **User decides:** preferences, priorities, budget, risk appetite,
     scope, facts only the user knows, or a choice between options that
     are each sound. Only these go to the user.

   Every question to the user comes with the options that are possible,
   their trade-offs, and the experts' recommendation.

## Phases

```
Phase 1  Frame the mission (with the user)
Phase 2  Form the council
Phase 3  Council round: experts investigate in parallel
Phase 4  Decision round with the user (batched)
Phase 5  Council sits together: cross-review, fold in the answers
         (repeat 3–5 until settled, at most 3 rounds)
Phase 6  Verify
Phase 7  Domain Expert Document, then Gate 1
```

**Roster-only requests.** Some users only want to know which experts are
needed ("what experts would I need for…", "just tell me the team"). For
these, run Phases 1–2, present the roster in the light format (2e), and
stop. Then offer to convene the council. Working out the roster is useful
on its own.

**Standing preferences.** If the user has standing preferences that bear on
the work, put them in the brief of every expert they affect. For example, a
rule like "always check whether a discount is genuine and whether reviews
are real" goes into the brief of any expert who assesses things to buy.
Experts only see their brief, so a preference left out of it will be
ignored.

---

## Phase 1: Frame the mission

Get the goal clear before choosing experts. The wrong goal produces the
wrong council. Write a short mission frame with the user:

- **Goal:** one sentence describing the end state, not the activity.
  ("A working wall-mounted mixer tap with no leaks", not "install tap".)
- **Context:** what already exists (current plumbing, existing codebase,
  budget, location, regulations that might apply), and the user's own
  knowledge level.
- **Scope:** what is in, and what is explicitly out.
- **Constraints:** time, money, and anything that must not change.
- **Unknowns:** facts that would change the picture. Mark each one either
  *ask the user* (only they know it) or *experts will find out*
  (researchable).

**Round 0.** Ask before Phase 2 only about unknowns that would change who
sits on the council. Example: whether the new tap goes in the same spot or
in a new wall position. For anything else, make a reasonable assumption,
write it down and continue. A wrong assumption that is written down is easy
to fix later. A hidden one is not.

---

## Phase 2: Form the council

The council is made of **domain specialists**: people who know the subject.
Examples are a plumber, a payments-compliance specialist or a podcast
producer. Architects come later, in the architect skill.

The roster is derived from the goal. It is not picked from a stock list.

### 2a. Find the questions

Walk the goal's lifecycle to find everything that must be understood. You
are mapping questions here, not planning work:

1. **Assess:** what is there now, and in what condition?
2. **Choices:** what has to be chosen (product, approach, standard,
   provider)?
3. **Acquire:** what materials, parts, services, accounts, permissions or
   data are involved?
4. **Do:** what does doing it involve, and what can go wrong?
5. **Verify:** how would anyone know it worked?
6. **Operate / maintain:** what happens after it is done?

Then apply the cross-cutting lenses. Each can reveal questions the
lifecycle walk missed:

- **Safety:** can someone get hurt, or something break, flood, leak or
  burn?
- **Compliance:** building codes, permits, licensing, legal, privacy,
  security standards.
- **Cost:** budget, cost of ownership, cheaper alternatives. When something
  will be bought, also check whether the price is honest:
  - compare the price history against any "% off MRP" claim;
  - check whether the seller is genuine or authorised;
  - check whether the reviews are real or botted.

  These checks usually need a buying expert, separate from the person who
  knows how the thing is fitted or built.
- **People:** who uses the result, and who is affected along the way?
- **Interfaces:** where does this touch an existing system someone else
  owns?

### 2b. Group the questions into experts

Group the questions by **the body of knowledge needed to answer them
well**. Each group becomes one expert. Apply these tests:

- **Split** a group when one person would need two unrelated kinds of
  expertise. A plumber is not the right person to judge both the valve and
  the tile finish.
- **Merge** two groups when the same expert would naturally cover both.
  Choosing the tap and judging its fit with the supply can both belong to
  the plumber.
- **Every expert owns at least one area of findings that nobody else
  owns.** If you cannot name one, the expert is padding. Remove them.
- **Every question has exactly one owner.** Others go on the card's
  `Reviews` line. Cross-cutting experts (security, safety, compliance) often
  own a small set of requirements and review everyone else's findings. That
  is a real role.
- **No cap on the number of experts.** A tap swap may need one; a hospital
  wing may need thirty. Above 8 experts, group them into teams with a lead
  each.
- **Conditional experts.** Some are needed only if something turns out to
  be true, for example an electrician if the chosen oven needs its own
  circuit. List them with their trigger.

Build the roster from domain knowledge. A quick check is fine when you are
unsure whether a role is needed at all, such as whether a permit regime
applies. Do not research the answers at this stage. Those go on an expert's
"Must answer" list, so that open questions are not stated as facts.

Scope changes the roster, and the frame should show that. A like-for-like
tap swap needs one plumber. A new wall-mounted mixer needs a plumber, a
mason or tiler, and a waterproofing specialist.

### 2c. Expert Card

```markdown
### Expert: <Role title>, <domain>
**Why needed:** <which questions from 2a this expert owns>
**Owns (findings):** <areas, as nouns: "supply pressure and pipe type", "GST rules for invoices">
**Does not own:** <adjacent areas that belong to someone else>
**Must answer:** <the questions this expert must settle or turn into decision requests>
**Depends on:** <experts whose findings this one needs first, or "none">
**Reviews:** <other experts' findings this one checks, or "none">
**Knows / relies on (real world):** <standards, references, tools a practitioner uses>
**Agent tools:** <web search, file reads of the user's photos or repo, a connected app>
**Subagents it may delegate to:** <narrow research sub-tasks, e.g. "compare 5 taps under ₹6,000 that fit a single-hole basin">
**Definition of Done:**
- [ ] ...
```

**Definition of Done for understanding work.** Phase 6 checks against these
items, so each must be markable *met* or *not met* by someone else without
guessing:

- Bad: "Understands the plumbing."
- Good: "Supply pipe size and pressure are stated, with evidence (photo,
  spec or measurement method)."

Every card includes these four items:

- [ ] Every Must-answer question is answered with evidence, or turned into
      a decision request.
- [ ] Every open choice in this area lists its options, their trade-offs
      and a recommendation.
- [ ] A user briefing is written in plain language.
- [ ] Requirements and notes for the architect are written down.

"Done" here means the understanding is complete and backed by evidence.
Nothing has been designed or built.

### 2d. Map dependencies into waves

Order experts by their `Depends on` lines. Experts with no dependencies run
in Wave 1, in parallel. The next wave holds those that need Wave 1's
findings, and so on.

If two experts each need the other first, resolve the cycle in one of three
ways:

- **One owner:** give the shared question to a single expert.
- **Assume, then check:** run one expert on an assumption and have the
  other expert check it.
- **Two passes:** run the same expert twice, and resume the same agent so
  it keeps its earlier reasoning.

### 2e. Present the roster

Show the user the **light format**:

- the mission frame, with its goal and key assumptions;
- a roster table (expert, what they cover, wave);
- for each expert: why they are needed, what they cover, real-world
  knowledge and tools, and their Definition of Done.

Leave out agent tools, subagent tasks and "Must answer" lists. To a
non-technical user these look like jargon.

Let the user adjust the roster. Adding or removing an expert now costs
nothing. Mention which assumptions are worth correcting first. If the user
said to just run it, or is away, continue and record the roster you used.

---

## Phase 3: Council round

You are the **coordinator**. You spawn one subagent per expert, wave by
wave. All experts in a wave are spawned in the same turn.

- **Experts usually cannot spawn their own subagents.** They send narrow
  sub-tasks back as "Delegation requests", and you run them.
- **Subagents may not be allowed to write files.** Experts return text, and
  you write any files.
- **If you cannot spawn subagents at all,** play each expert in turn, in
  wave order, working from their card alone. Say in the document that the
  council was simulated and that verification was not independent.

Each expert's brief is the only context it has:

```
You are the <Role title> on a council of domain experts working with the user toward:
<mission frame: goal, context, scope, constraints, assumptions>

Hard rule: you investigate and advise. You never implement: no deliverable
code, no changes to the user's files or systems, no purchases, nothing run
against live systems. You decide WHAT is needed and WHY. HOW it is designed
belongs to the architects who come after you.

Your Expert Card:
<card>

What the user has decided so far:
<decision log, or "nothing yet">

Findings from other experts:
<their outputs, or "none, you are in Wave 1">

Sort every open item: decide it yourself if it is a matter of expertise;
research it if it is a findable fact; send it to the user ONLY if it is
theirs to decide (preference, priority, budget, risk appetite, scope, a fact
only they know).

Return exactly:
## Findings            (answers to Must answer, with evidence and sources)
## Requirements        (what the eventual solution must / should / must not do, from your area)
## Decisions made      (what you settled as the expert, and why)
## Options             (each open choice: options, trade-offs, your recommendation)
## Decision requests   (only the user's to make: question; why it is theirs; options; recommendation; what changes downstream)
## User briefing       (at most 150 words, plain language: what the user must understand about your area)
## Notes for the architect
## Handoffs            (to other experts)
## Definition of Done  (each item MET / PARTIAL / NOT MET, with evidence)
## Delegation requests (only if you could not spawn subagents)
## Confidence          (high / medium / low, with one line why)
```

When an expert returns delegation requests, run them and give the results
back to that expert, continuing the same agent if possible. Pass each
expert's handoffs on to the experts in later waves that depend on them.

---

## Phase 4: Decision round with the user

1. Collect every decision request from the round.
2. Remove duplicates and merge related ones.
3. Send back to its expert anything the expert could settle alone.
4. Order the rest by impact. Decisions that change other experts' work go
   first.
5. Show the relevant user briefings first, so the user decides with the
   domain knowledge in hand.
6. Ask in one batch. For each question give:
   - a sentence of context;
   - the options that are possible;
   - their trade-offs;
   - the experts' recommendation;
   - what the answer affects.

   Use the question tool if you have one: up to 4 questions per call, with
   the recommended option first. Otherwise use a numbered list.
7. Log every answer: the decision, the options considered, the choice, who
   decided, and why.

If the user says "you decide", log it as an expert decision delegated by
the user. If the user is away, take the recommendation and log it as
*assumed, confirm at Gate 1*.

---

## Phase 5: The council sits together

Give each expert the user's answers and a summary of the other experts'
findings. Continue the same agent where possible. Each expert then:

- updates their findings with the user's decisions;
- flags conflicts with other experts' findings;
- raises new questions that the others' findings created.

The coordinator resolves conflicts by owner. A conflict that is a genuine
trade-off only the user can make goes into the next decision round.

Repeat Phases 3–5 until there are no open decision requests and no
unresolved conflicts, for at most 3 rounds. Anything still open after that
goes into the document as an open question.

---

## Phase 6: Verify

The experts graded themselves. Don't take those grades as final. Check
every Definition of Done item against the evidence:

- **MET:** the evidence is there and supports the claim.
- **PARTIAL:** some of it is done, or the evidence is thin. Say what is
  missing.
- **NOT MET:** missing, wrong, or claimed without evidence.

**High-stakes goals.** These are goals where a mistake could hurt someone,
flood or damage property, cost real money, break a law or a compliance
rule, or weaken security. For each expert on such a goal, spawn a separate
verifier. Give it the card and the findings, not the self-grades. If you
can't spawn one, do a deliberately adversarial second pass yourself, and
recommend that a human review those parts.

**Integration check.** Individual experts can each pass while the whole
still fails:

- Do any requirements contradict each other?
- Is every user decision reflected in the findings?
- Did any question from 2a go unanswered?

Send gaps back to the owning expert for up to two rework rounds. If a gap
is still open after that, report it as an open item: what is missing, why,
and what would close it. A document that is honest about a gap is worth
more than one that falsely claims completeness.

---

## Phase 7: Domain Expert Document and Gate 1

Deliver the document in the format the environment favours for a document
the user will keep (a doc artifact, a markdown file, and so on).

Size it to the job. With 3 or fewer experts, the short cards go in "The
council". With more, "The council" holds a table and the full cards go in an
appendix.

```markdown
# Domain Expert Document: <goal>
Status: Draft, awaiting approval

## Summary            <3–5 sentences: what the problem really is, what it demands, biggest risk, feasibility>
## Mission & scope    <goal, in / out of scope, constraints, assumptions>
## Domain primer      <the user briefings merged; glossary>
## The council        <table: expert, covered, DoD status>
## Findings           <by area, with evidence and sources>
## Requirements       <must / should / must not; prerequisites (permits, access, data, materials);
                       what success looks like, in measurable terms>
## Decision log       <decision · options considered · chosen · decided by (user / expert / assumed) · why>
## Risks & assumptions
## Open questions for the architect
## Handoff to the architect  <what is fixed and must be respected; what is left to design>
## Verification scorecard
```

The document contains no design, no architecture and no build plan. Those
come from the architect skill.

**Gate 1.** Give the user a short summary and the document, then ask them
to choose:

- **Approve:** set Status to "Approved by user on <date>", then offer to
  start the architect skill with this document.
- **Request changes:** route each change to the owning expert, re-verify,
  and present the document again.
- **Stop.**

Never start the architect stage without this approval.

---

## Worked example: "install a tap in the bathroom"

This shows the method. It is not a template to copy.

**Mission frame.** The goal is a working basin tap with no leaks.

**Round 0.** Ask: "Same spot as the old tap, or a new wall position?" The
answer changes the council.

**Like-for-like replacement.** The council is a **Plumber**, plus a
**Fittings Buyer** if the user wants the purchase checked for an honest
price and genuine reviews. That toolkit is market research, not plumbing.
The Plumber's card:

### Expert: Plumber, domestic water supply
**Why needed:** owns everything about the supply side and fitting
requirements.
**Owns (findings):** basin hole count, supply pipe size and pressure,
isolation valves, connector threads.
**Does not own:** tile or wall work; electrical.
**Must answer:** Which tap types fit this basin and supply? Are the
isolation valves present and working? Which connector length and thread?
**Depends on:** none.
**Knows / relies on:** pressure ratings, connector standards, manufacturer
spec sheets.
**Agent tools:** web search (tap specs, threads); image read (the user's
photos of the under-basin area).
**Definition of Done:**
- [ ] Hole count, pipe size and pressure stated, with evidence
- [ ] Compatible tap types listed, with trade-offs and a recommendation
- [ ] User briefing explains isolation valves and why pressure matters
- [ ] Requirements for the architect written (e.g. "must work at the measured low pressure")

The Plumber decides alone that flexible connectors of the right thread are
needed. It asks the user only things like "Single-lever mixer or separate
hot and cold taps?", with the trade-offs and a recommendation.

**New wall-mounted mixer.** Add a **Mason / Tiler** (wall build-up, tile
type, making good) and a **Waterproofing specialist** (membrane needs). The
requirements now include:

- a concealed valve body rated for the measured pressure;
- a membrane continuous behind the valve;
- a pressure test before the wall is closed.

How to route the pipes is left to the architect.

**A software goal works the same way.** "Build a multi-tenant SaaS billing
service" might convene a Payments and PCI-compliance expert, a Finance/tax
expert (invoicing rules, GST/VAT), a Security expert, and an expert on the
billing domain's customers and pricing models. They settle what the service
must do and which rules bind it. The system design comes from the architect
skill.